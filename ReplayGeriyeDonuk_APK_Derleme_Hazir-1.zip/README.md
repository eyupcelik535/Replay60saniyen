# Replay • Son Saniyeler (Android Studio projesi)

PUBG Mobile dahil ekrandaki görüntünün **geçmiş** 15/30/60 saniyesini bir tuşla MP4'e kaydetmek için hazırlanmış deneme (beta) Android uygulaması.

## Nasıl çalışır?

1. **Geriye dönük kaydı başlat** → Android'in **ekran paylaşım** iznini kabul et. (Oyun değiştirirken çalışması için *tüm ekranı paylaş* seçeneğini kullan.)
2. Uygulama ekranı H.264 formatında sürekli kodlar, ama MP4'ü kaydetmez: sıkıştırılmış kareler yalnızca RAM'deki yaklaşık 64 saniyelik döngüsel tamponda bekler.
3. PUBG Mobile'ı aç; bir anı saklamak istediğinde üstteki `↺ 30 sn` düğmesine veya bildirimdeki **Klip kaydet** eylemine dokun.
4. Seçilen **geçmiş** 15/30/60 saniye (tampon yeni başlatıldıysa o ana kadar mevcut süre) **Galeri → Filmler/ReplayGeriye** klasörüne MP4 olarak yazılır.
5. Durdur düğmesi tamponu kapatır ve RAM'deki geçmiş silinir. Düzenli aralıklarla tam ekran videosu *dosyaya* kaydedilmez.

## Android Studio ile açma

- Android Studio **File → Open** yolundan `ReplayGeriyeDonuk` klasörünü seç.
- Android SDK 35, JDK 17 ve Gradle 8.9 / Android Gradle Plugin 8.7.3 kurulu olmalı; IDE bunları indirebilir.
- Android Studio içinden **Build → Build APK(s)**; sonra `app/build/outputs/apk/debug/app-debug.apk` dosyasını cihazına yükle.
- Proje klasöründe Gradle Wrapper ayar dosyası vardır. Bu ZIP'te `gradle-wrapper.jar` yoktur; Android Studio'nun Gradle ayarını/yerel Gradle kurulumunu kullan. Komut satırında Gradle kullanmak istersen `gradle wrapper --gradle-version 8.9` ile normal wrapper dosyalarını oluştur.
- Test için gerçek cihaz gereklidir (Android 10+). Emulator'da ekran yansıtma davranışı farklı olabilir.

## Ayarlar

| Ayar | Değerler |
|---|---|
| Geriye dönük süre | 15 / 30 / 60 sn |
| Görüntü çözünürlüğü | 720p / 1080p (ekranın kısa kenarına göre, üst sınır) |
| Kare hızı | 30 / 60 FPS (cihaz/codec izin verirse) |
| Video bit hızı | 6 / 12 / 20 Mbps |
| Oyun içi ses | Aç/Kapat (Android'in izin verdiği uygulamalar için) |

Çözünürlük, FPS, bit hızı ve ses değişikliği için tamponu **durdurup yeniden başlat**. Süre seçimi ise anlık kaydetme işlemine yansır.

## Sınırlamalar (önemli)

- Uygulama **önceden başlatılmadan** geriye kayıt yapılamaz. Android hiçbir üçüncü taraf uygulamaya henüz yakalanmamış ekranın geçmişini vermez.
- Android, aktif ekran yakalamayı bir **görünür bildirim/gösterge** ile belirtir. Ekran paylaşım izni her yeni oturumda yeniden alınmalıdır; Android 15 QPR1+ sürümleri ekran kilitlenince yakalamayı durdurabilir.
- Oyun içi ses sadece oyunun Android `AudioPlaybackCapture` politikasına izin vermesi halinde kaydedilebilir; aksi halde ses olmayabilir. Mikrofon sesi bu beta sürümde kaydedilmez.
- H.264 donanım kodlama, 60 FPS, çözünürlük ve kayıt kalitesi cihazın donanım sınırlarına bağlıdır. Enerji ve RAM tüketimi vardır. Ekran dönerse doğru oran için yeniden başlatmak gerekebilir.
- Bazı korumalı uygulamalar/sahneler yakalamaya izin vermez ve siyah görüntü verebilir.
- Bu bir **kaynak kodu projesidir**, imzalanmış veya cihazda test edilmiş bir APK değildir. Oluşturulduğu ortamda Android SDK/Gradle bulunmadığından derleme testi yapılamadı; gerçek cihazda doğrulama gerekebilir.
- Video tamponu yaklaşık 64 saniye korunur ve 180 MiB video RAM sınırına tabidir; çok yüksek bit hızında zaman aralığı kısalabilir. Klip başlangıcı anahtar kareye (keyframe) yuvarlandığından seçilen süreden yaklaşık 1 sn uzun olabilir.

## Tasarım / kaynaklar

- Ekran: `MediaProjection` → `VirtualDisplay` → `MediaCodec` (H.264 yüzeyi)
- Ses: uygun oyunlar için `AudioPlaybackCaptureConfiguration` → `AudioRecord` → `MediaCodec` (AAC)
- Zaman damgalı bellek tamponu: `ReplayBuffer.java`
- Sadece düğmeye basıldığında: `MediaMuxer` → `MediaStore` (MP4)
- Görünür foreground service, oyun üstü düğme ve kalıcı bildirim: `ReplayService.java`

Android resmi belgeler:

- https://developer.android.com/media/grow/media-projection
- https://developer.android.com/media/platform/av-capture
- https://developer.android.com/develop/background-work/services/fgs/service-types
