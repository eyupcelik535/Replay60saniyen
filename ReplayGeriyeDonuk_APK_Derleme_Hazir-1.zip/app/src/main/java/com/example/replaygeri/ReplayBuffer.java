package com.example.replaygeri;

import android.media.MediaCodec;
import android.media.MediaFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/** In-memory circular buffer: no rolling MP4 files written to permanent storage. */
final class ReplayBuffer {
    private static final long KEEP_US = 64_000_000L;
    private static final long MAX_VIDEO_BYTES = 180L * 1024 * 1024;
    private final LinkedList<EncodedSample> video = new LinkedList<>();
    private final LinkedList<EncodedSample> audio = new LinkedList<>();
    private long bytes = 0;
    private long latestVideoUs = -1;
    private MediaFormat videoFormat;
    private MediaFormat audioFormat;

    static final class EncodedSample {
        final byte[] data;
        final long ptsUs;
        final int flags;
        EncodedSample(byte[] data, long ptsUs, int flags) {
            this.data = data; this.ptsUs = ptsUs; this.flags = flags;
        }
        boolean isKeyFrame() { return (flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0; }
    }
    static final class Snapshot {
        final List<EncodedSample> video;
        final List<EncodedSample> audio;
        final MediaFormat videoFormat;
        final MediaFormat audioFormat;
        final long basePtsUs;
        Snapshot(List<EncodedSample> video, List<EncodedSample> audio, MediaFormat v,
                 MediaFormat a, long base) {
            this.video = video; this.audio = audio; this.videoFormat = v;
            this.audioFormat = a; this.basePtsUs = base;
        }
    }

    synchronized void setVideoFormat(MediaFormat value) { videoFormat = value; }
    synchronized void setAudioFormat(MediaFormat value) { audioFormat = value; }

    synchronized void appendVideo(EncodedSample sample) {
        video.add(sample);
        bytes += sample.data.length;
        latestVideoUs = Math.max(latestVideoUs, sample.ptsUs);
        prune();
    }

    synchronized void appendAudio(EncodedSample sample) {
        audio.add(sample);
        prune();
    }

    private void prune() {
        if (latestVideoUs < 0) return;
        long cutoff = latestVideoUs - KEEP_US;
        while (!video.isEmpty() && (video.peekFirst().ptsUs < cutoff || bytes > MAX_VIDEO_BYTES)) {
            bytes -= video.removeFirst().data.length;
        }
        // Older audio also gets discarded; both tracks use monotonic microseconds.
        while (!audio.isEmpty() && audio.peekFirst().ptsUs < cutoff) audio.removeFirst();
    }

    synchronized Snapshot snapshot(int seconds) {
        if (videoFormat == null || video.isEmpty()) return null;
        long requestedStart = latestVideoUs - Math.max(1, Math.min(60, seconds)) * 1_000_000L;
        EncodedSample key = null;
        for (EncodedSample s : video) {
            if (s.isKeyFrame() && s.ptsUs <= requestedStart) key = s;
            if (s.ptsUs > requestedStart) break;
        }
        // If fewer than N seconds are available, use the earliest valid key frame.
        if (key == null) for (EncodedSample s : video) if (s.isKeyFrame()) { key = s; break; }
        if (key == null) return null;
        long base = key.ptsUs;
        ArrayList<EncodedSample> v = new ArrayList<>();
        for (EncodedSample s : video) if (s.ptsUs >= base && s.ptsUs <= latestVideoUs) v.add(s);
        ArrayList<EncodedSample> a = new ArrayList<>();
        if (audioFormat != null) {
            for (EncodedSample s : audio) if (s.ptsUs >= base && s.ptsUs <= latestVideoUs) a.add(s);
        }
        if (v.isEmpty()) return null;
        return new Snapshot(v, a, videoFormat, a.isEmpty() ? null : audioFormat, base);
    }
}
