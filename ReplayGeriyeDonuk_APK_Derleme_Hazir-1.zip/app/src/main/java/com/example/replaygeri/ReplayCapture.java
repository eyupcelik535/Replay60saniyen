package com.example.replaygeri;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.net.Uri;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.view.Surface;
import android.view.WindowManager;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Encodes screen to H.264 continuously in a bounded RAM ring, saves only on demand. */
final class ReplayCapture {
    interface SaveListener { void done(boolean success, String detail); }
    private final Context app;
    private final ReplayBuffer ring = new ReplayBuffer();
    private MediaCodec videoEncoder;
    private MediaCodec audioEncoder;
    private AudioRecord audioRecord;
    private VirtualDisplay virtualDisplay;
    private Surface inputSurface;
    private Thread videoDrainThread, audioDrainThread, audioFeedThread;
    private volatile boolean running;
    private final AtomicBoolean saving = new AtomicBoolean(false);

    ReplayCapture(Context context) { app = context.getApplicationContext(); }

    void start(MediaProjection projection, SharedPreferences p) throws Exception {
        int targetShortEdge = p.getInt("quality", 1080);
        int fps = p.getInt("fps", 60);
        int bitrate = p.getInt("mbps", 12) * 1_000_000;
        WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
        int screenWidth, screenHeight;
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect r = wm.getMaximumWindowMetrics().getBounds();
            screenWidth = r.width(); screenHeight = r.height();
        } else {
            Point size = new Point(); wm.getDefaultDisplay().getRealSize(size);
            screenWidth = size.x; screenHeight = size.y;
        }
        float scale = Math.min(1f, targetShortEdge / (float) Math.min(screenWidth, screenHeight));
        // AVC encoders commonly require aligned dimensions.
        int width = Math.max(16, Math.round(screenWidth * scale) / 16 * 16);
        int height = Math.max(16, Math.round(screenHeight * scale) / 16 * 16);
        MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        videoEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        inputSurface = videoEncoder.createInputSurface();
        videoEncoder.start();
        running = true;
        videoDrainThread = new Thread(() -> drain(videoEncoder, true), "Replay-VideoDrain");
        videoDrainThread.start();

        int density = app.getResources().getConfiguration().densityDpi;
        virtualDisplay = projection.createVirtualDisplay("ReplayBack",
                width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface, null, null);
        if (p.getBoolean("audio", true) && app.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try { startPlaybackAudio(projection); }
            catch (Exception audioUnavailable) { releaseAudioOnly(); }
        }
    }

    private void startPlaybackAudio(MediaProjection projection) throws Exception {
        final int sampleRate = 48_000;
        final int channels = 2;
        AudioPlaybackCaptureConfiguration config = new AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .build();
        int min = AudioRecord.getMinBufferSize(sampleRate,
                AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) throw new IllegalStateException("Audio input not supported");
        audioRecord = new AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(config)
                .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build())
                .setBufferSizeInBytes(Math.max(min * 2, 16_384))
                .build();
        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED)
            throw new IllegalStateException("AudioRecord could not initialize");
        MediaFormat audioFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,
                sampleRate, channels);
        audioFormat.setInteger(MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        audioFormat.setInteger(MediaFormat.KEY_BIT_RATE, 128_000);
        audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        audioEncoder.start();
        audioRecord.startRecording();
        final MediaCodec codec = audioEncoder;
        final AudioRecord recorder = audioRecord;
        audioDrainThread = new Thread(() -> drain(codec, false), "Replay-AudioDrain");
        audioFeedThread = new Thread(() -> {
            final int targetBytes = 4096;
            try {
                while (running && recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    int index = codec.dequeueInputBuffer(10_000);
                    if (index < 0) continue;
                    ByteBuffer input = codec.getInputBuffer(index);
                    if (input == null) continue;
                    input.clear();
                    int limit = Math.min(targetBytes, input.remaining());
                    // Android returns PCM captured from eligible games only.
                    int length = recorder.read(input, limit, AudioRecord.READ_BLOCKING);
                    if (length > 0) {
                        long durationUs = length * 1_000_000L / (sampleRate * channels * 2);
                        long presentationUs = System.nanoTime() / 1000L - durationUs;
                        codec.queueInputBuffer(index, 0, length, presentationUs, 0);
                    } else codec.queueInputBuffer(index, 0, 0, System.nanoTime() / 1000L, 0);
                }
            } catch (IllegalStateException ignored) { /* projection stopped */ }
        }, "Replay-AudioFeed");
        audioDrainThread.start();
        audioFeedThread.start();
    }

    private void drain(MediaCodec codec, boolean isVideo) {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        try {
            while (running) {
                int index = codec.dequeueOutputBuffer(info, 10_000);
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (isVideo) ring.setVideoFormat(codec.getOutputFormat());
                    else ring.setAudioFormat(codec.getOutputFormat());
                } else if (index >= 0) {
                    ByteBuffer encoded = codec.getOutputBuffer(index);
                    if (encoded != null && info.size > 0 &&
                            (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        byte[] data = new byte[info.size];
                        encoded.position(info.offset);
                        encoded.limit(info.offset + info.size);
                        encoded.get(data);
                        ReplayBuffer.EncodedSample sample = new ReplayBuffer.EncodedSample(
                                data, info.presentationTimeUs, info.flags);
                        if (isVideo) ring.appendVideo(sample);
                        else ring.appendAudio(sample);
                    }
                    codec.releaseOutputBuffer(index, false);
                }
            }
        } catch (IllegalStateException ignored) { /* encoder torn down */ }
    }

    void saveLast(int seconds, SaveListener listener) {
        if (!running) { listener.done(false, "Tampon durduruldu."); return; }
        if (!saving.compareAndSet(false, true)) {
            listener.done(false, "Bir klip zaten kaydediliyor."); return;
        }
        final ReplayBuffer.Snapshot snapshot = ring.snapshot(seconds);
        if (snapshot == null || snapshot.video.size() < 3) {
            saving.set(false);
            listener.done(false, "Tampon henüz hazır değil. 2 saniye sonra tekrar dene.");
            return;
        }
        new Thread(() -> {
            try {
                String filename = muxToGallery(snapshot);
                listener.done(true, filename);
            } catch (Exception e) {
                listener.done(false, "Kaydetme hatası: " + e.getMessage());
            } finally { saving.set(false); }
        }, "Replay-MP4Writer").start();
    }

    private String muxToGallery(ReplayBuffer.Snapshot snapshot) throws Exception {
        String filename = "Replay_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                .format(new Date()) + ".mp4";
        ContentResolver resolver = app.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ReplayGeriye");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri item = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (item == null) throw new Exception("MediaStore kaydı açılamadı");
        boolean success = false;
        try (ParcelFileDescriptor fd = resolver.openFileDescriptor(item, "w")) {
            if (fd == null) throw new Exception("Video dosyası açılamadı");
            MediaMuxer muxer = new MediaMuxer(fd.getFileDescriptor(),
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            try {
                int videoTrack = muxer.addTrack(snapshot.videoFormat);
                int audioTrack = snapshot.audioFormat == null ? -1 : muxer.addTrack(snapshot.audioFormat);
                muxer.start();
                // MediaMuxer can accept samples from tracks in timestamp order.
                int vi = 0, ai = 0;
                while (vi < snapshot.video.size() || (audioTrack >= 0 && ai < snapshot.audio.size())) {
                    boolean writeVideo;
                    if (vi >= snapshot.video.size()) writeVideo = false;
                    else if (audioTrack < 0 || ai >= snapshot.audio.size()) writeVideo = true;
                    else writeVideo = snapshot.video.get(vi).ptsUs <= snapshot.audio.get(ai).ptsUs;
                    ReplayBuffer.EncodedSample s = writeVideo ? snapshot.video.get(vi++) : snapshot.audio.get(ai++);
                    MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                    info.set(0, s.data.length, Math.max(0, s.ptsUs - snapshot.basePtsUs),
                            s.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME);
                    muxer.writeSampleData(writeVideo ? videoTrack : audioTrack, ByteBuffer.wrap(s.data), info);
                }
                muxer.stop();
                success = true;
            } finally { muxer.release(); }
        } finally {
            if (success) {
                ContentValues done = new ContentValues(); done.put(MediaStore.Video.Media.IS_PENDING, 0);
                resolver.update(item, done, null, null);
            } else resolver.delete(item, null, null);
        }
        return filename;
    }

    void stop() {
        running = false;
        if (audioRecord != null) {
            try { audioRecord.stop(); } catch (Exception ignored) { }
        }
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (Exception ignored) { }
            virtualDisplay = null;
        }
        join(videoDrainThread); join(audioFeedThread); join(audioDrainThread);
        releaseAudioOnly();
        if (videoEncoder != null) {
            try { videoEncoder.stop(); } catch (Exception ignored) { }
            try { videoEncoder.release(); } catch (Exception ignored) { }
            videoEncoder = null;
        }
        if (inputSurface != null) { inputSurface.release(); inputSurface = null; }
    }

    private void releaseAudioOnly() {
        if (audioEncoder != null) {
            try { audioEncoder.stop(); } catch (Exception ignored) { }
            try { audioEncoder.release(); } catch (Exception ignored) { }
            audioEncoder = null;
        }
        if (audioRecord != null) {
            try { audioRecord.release(); } catch (Exception ignored) { }
            audioRecord = null;
        }
    }

    private void join(Thread thread) {
        if (thread != null && Thread.currentThread() != thread)
            try { thread.join(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
