package com.example.replaygeri;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class ReplayService extends Service {
    public static final String ACTION_START = "com.example.replaygeri.START";
    public static final String ACTION_SAVE = "com.example.replaygeri.SAVE";
    public static final String ACTION_STOP = "com.example.replaygeri.STOP";
    public static final String ACTION_OVERLAY = "com.example.replaygeri.OVERLAY";
    private static final int NOTIFICATION_ID = 427;
    private static final String CHANNEL = "replay_running";
    public static volatile boolean active = false;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private ReplayCapture capture;
    private MediaProjection projection;
    private boolean stopping;
    private WindowManager windowManager;
    private TextView overlay;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Geriye dönük kayıt",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Ekran yakalamanın açık olduğunu gösterir.");
        manager.createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        switch (intent.getAction()) {
            case ACTION_START:
                if (!active && capture == null) startCapture(intent);
                break;
            case ACTION_SAVE:
                if (!active || capture == null) toast("Önce tampon kaydı başlat.");
                else {
                    int seconds = intent.getIntExtra("seconds", getSharedPreferences("settings", MODE_PRIVATE)
                            .getInt("duration", 30));
                    capture.saveLast(seconds, (ok, detail) -> toast(ok
                            ? "Galeriye kaydedildi: " + detail : detail));
                }
                break;
            case ACTION_OVERLAY:
                if (active) showOverlay();
                break;
            case ACTION_STOP:
                stopCapture();
                stopSelf();
                break;
        }
        return START_NOT_STICKY;
    }

    private void startCapture(Intent permission) {
        try {
            // Foreground service MUST be established before getMediaProjection on Android 14+.
            startForeground(NOTIFICATION_ID, notification());
            int resultCode = permission.getIntExtra("resultCode", 0);
            Intent data;
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                data = permission.getParcelableExtra("resultData", Intent.class);
            } else data = permission.getParcelableExtra("resultData");
            if (data == null || resultCode != android.app.Activity.RESULT_OK)
                throw new IllegalStateException("Ekran paylaşım izni alınmadı");
            MediaProjectionManager manager = (MediaProjectionManager)
                    getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, data);
            if (projection == null) throw new IllegalStateException("MediaProjection yok");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    ui.post(() -> { if (!stopping) { toast("Ekran yakalama Android tarafından durduruldu.");
                        stopCapture(); stopSelf(); } });
                }
            }, ui);
            SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
            capture = new ReplayCapture(this);
            capture.start(projection, prefs);
            active = true;
            showOverlay();
            toast("Geriye dönük tampon aktif. " + prefs.getInt("duration", 30) + " sn hazırlandığında kaydedebilirsin.");
        } catch (Exception error) {
            toast("Kayıt açılamadı: " + error.getMessage());
            stopCapture();
            stopSelf();
        }
    }

    private Notification notification() {
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 10, open, flags);
        Intent save = new Intent(this, ReplayService.class).setAction(ACTION_SAVE);
        PendingIntent saveAction = PendingIntent.getService(this, 11, save, flags);
        Intent stop = new Intent(this, ReplayService.class).setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, 12, stop, flags);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_save)
                .setContentTitle("Replay tamponu açık")
                .setContentText("Son 15/30/60 saniyeyi kaydetmek için dokun")
                .setOngoing(true).setContentIntent(content)
                .addAction(new Notification.Action.Builder(null, "Klip kaydet", saveAction).build())
                .addAction(new Notification.Action.Builder(null, "Durdur", stopAction).build())
                .build();
    }

    private void showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return;
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            TextView bubble = new TextView(this);
            bubble.setText("↺ " + getSharedPreferences("settings", MODE_PRIVATE).getInt("duration", 30) + " sn");
            bubble.setTextSize(14);
            bubble.setTextColor(0xFFFFFFFF);
            bubble.setGravity(Gravity.CENTER);
            bubble.setBackgroundTintList(null);
            android.graphics.drawable.GradientDrawable background = new android.graphics.drawable.GradientDrawable();
            background.setColor(0xE51D847E);
            background.setCornerRadius(70f);
            background.setStroke(2, 0xFFB9F6EB);
            bubble.setBackground(background);
            bubble.setPadding(16, 10, 16, 10);
            int w = (int) (92 * getResources().getDisplayMetrics().density);
            int h = (int) (49 * getResources().getDisplayMetrics().density);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(w, h,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.RIGHT;
            params.x = 10;
            params.y = (int) (280 * getResources().getDisplayMetrics().density);
            bubble.setOnTouchListener(new View.OnTouchListener() {
                float initialX, initialY, downRawX, downRawY;
                boolean moved;
                @Override public boolean onTouch(View view, MotionEvent event) {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            initialX = params.x; initialY = params.y;
                            downRawX = event.getRawX(); downRawY = event.getRawY();
                            moved = false; return true;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getRawX() - downRawX;
                            float dy = event.getRawY() - downRawY;
                            if (Math.abs(dx) + Math.abs(dy) > 20) moved = true;
                            if (moved) {
                                params.x = (int) (initialX - dx);
                                params.y = (int) (initialY + dy);
                                try { windowManager.updateViewLayout(bubble, params); }
                                catch (Exception ignored) { }
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (!moved) {
                                Intent save = new Intent(ReplayService.this, ReplayService.class);
                                save.setAction(ACTION_SAVE);
                                // Defaults to current selection.
                                startService(save);
                            }
                            return true;
                        default: return true;
                    }
                }
            });
            windowManager.addView(bubble, params);
            overlay = bubble;
        } catch (Exception error) { toast("Üst düğme açılamadı: " + error.getMessage()); }
    }

    private void removeOverlay() {
        if (overlay != null && windowManager != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) { }
            overlay = null;
        }
    }

    private void stopCapture() {
        if (stopping) return;
        stopping = true;
        active = false;
        removeOverlay();
        if (capture != null) {
            capture.stop();
            capture = null;
        }
        if (projection != null) {
            try { projection.stop(); } catch (Exception ignored) { }
            projection = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
    }

    private void toast(String message) { ui.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show()); }
    @Override public void onDestroy() { stopCapture(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
